## The framework for Healthline;
Is Minimal Viable Product (MVP) 

## Why Minimal Viable Product (MVP)?
This framework will allow us to introduce Healthline into the market in the early stages of development, in order to elicit feedback and find product-market as quickly as possible. And also, avoid spending all of the resources building out the product in its entirety before determining if it will succeed. Minimal Viable Product (MVP) will prevent having to build aspects of the product that may have been unnecessary(i.e features). 

The key reason to start small is that it allows us to determine which features our users’ love, and which features are unnecessary.
